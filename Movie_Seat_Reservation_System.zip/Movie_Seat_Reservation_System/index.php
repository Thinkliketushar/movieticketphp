<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link href="https://fonts.googleapis.com/css2?family=Baloo+Da+2:wght@500&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <link rel="icon" href="{{ url_for('static', filename='img/logo.png') }}" type="image/x-icon" />
        <link rel="shortcut icon" href="{{ url_for('static', filename='img/logo.png') }}" type="image/x-icon" />
        <title>MoviesWala Present</title>
        <link src="admin/assets/font-awesome/css/all.js"/>
        <script src="admin/assets/vendor/jquery/jquery.min.js"></script>
        <script src="admin/assets/font-awesome/js/all.js"></script>
       
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">

<header id="nav-placeholder" style="padding-top: 66px;">
    <nav style="background-color: black !important ;" id="nav"
      class="navbar navbar-expand-lg navbar-dark fixed-top bg-dark">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul style="font-size: 20px;" class="navbar-nav mr-auto">
          <li  class="nav-item active">
            <a style="color: #ffbd39;;" class="nav-link" href="index.php?page=home"><i class="fa fa-home"></i> Home
              <span class="sr-only">(current)</span></a>
          </li>

          <li class="nav-item">
            <a style="color: white;" class="nav-link" href="index.php?page=movies" id="navbarDropdown" role="button"
              aria-expanded="false">
             Movies tickets
            </a>
          </li>
          <li class="nav-item">
          <a style="color: white;" class="nav-link" href="index.php?page=movies" id="navbarDropdown" role="button"
              aria-expanded="false">
             Web series
            </a> 
          </li>
          <a style="color: white;" class="nav-link" href="index.php?page=movies" id="navbarDropdown" role="button"
              aria-expanded="false">
             Upcoming Movies
            </a>
          <li class="nav-item">
            <a style="color: white;" class="nav-link" href="index.php?page=movies" id="navbarDropdown" role="button"
              aria-expanded="false">
             Subscription
            </a>
          </li>
    
          <li class="nav-item">
            <a style="color: white;" class="nav-link" href="index.php?page=movies" id="navbarDropdown" role="button"
              aria-expanded="false">
             Events
            </a>
          </li>
          <li class="nav-item">
            <a style="color: white;" class="nav-link" href="index.php?page=movies" id="navbarDropdown" role="button"
              aria-expanded="false">
             Offer
            </a>
          </li>
          <li class="nav-item">
            <a style="color: white;" class="nav-link" href="index.php?page=movies" id="navbarDropdown" role="button"
              aria-expanded="false">
             About Us
            </a>
          </li>

        </ul>
        <div>
          <button style="color: #ffbd39;background: #000000; border: 2px solid #000000; font-size: 200%; box-shadow: 0 0 0 .2rem rgba(15, 15, 15, 0.5); " type="button">
         <a style="color: #ffbd39;" href=""> <i class="fab fa-facebook-f"></i> &nbsp;</a>
         <a style="color: #ffbd39;" href=""> <i class="fab fa-instagram"></i>&nbsp;</a>
         <a style="color: #ffbd39;" href=""> <i class="fab fa-google"></i>&nbsp;</a>
          </button>
        </div>
    </nav>
    <style>
      a {
        text-decoration: none;
        display: inline-block;
        position: relative;
      }

      a:after {
        background: none repeat scroll 0 0 transparent;
        bottom: 0;
        content: "";
        display: block;
        height: 2px;
        left: 50%;
        position: absolute;
        background: #ffbd39;
        ;
        transition: width 0.3s ease 0s, left 0.3s ease 0s;
        width: 0;
      }

      a:hover:after {
        width: 100%;
        left: 0;
      }

      @media screen and (max-height: 300px) {
        ul {
          margin-top: 40px;
        }
      }
    </style>
  </header>



       <?php

       $page = isset($_GET['page']) ? $_GET['page'] : 'home';
       include($page.'.php');
       ?>
        <!-- Footer-->
        <!-- <footer class="bg-light py-5">
            <div class="container"><div class="small text-center text-muted">Copyright © 2020 - Movievala.com</div></div>
        </footer> -->
        <footer class="bg-dark text-center text-white">
  <!-- Grid container -->
  <!-- Copyright -->
  <div style= "background-color: rgb(0, 0, 0);" class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2022 Copyright:
    <h2><a class="text-white" href="https://mdbootstrap.com/">MoviesWala.com</a></h2>
  </div>
  <!-- Copyright -->
</footer>
        <!-- Bootstrap core JS-->
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
        <!-- Third party plugin JS-->
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>


<style>
.text-white {
  color: #ffbd39 !important;
}
</style>
</html>